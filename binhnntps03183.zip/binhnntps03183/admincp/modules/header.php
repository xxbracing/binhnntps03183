<div class="header">
    	<h1 align="center" style="line-height:120px">Trang quản trị nội dung</h1>
    </div>