<script src="http://js.nicedit.com/nicEdit-latest.js" type="text/javascript"></script>
<script type="text/javascript">bkLib.onDomLoaded(nicEditors.allTextAreas);</script>
<form action="modules/video/xuly.php" method="post" enctype="multipart/form-data">
<table width="200" border="1">
  <tr>
    <td colspan="2">Thêm video</td>
  </tr>
  <tr>
    <td>Tên video</td>
    <td>
    <input type="text" name="tenvideo" id="tenbaiviet"></td>
  </tr>
  <tr>
    <td>Ảnh video</td>
    <td>
      <input type="file" name="anhvideo" id="anhminhhoa" /></td>
  </tr>
  <tr>
    <td>Link video</td>
    <td><label for="linkvideo"></label>
      <input type="text" name="linkvideo" id="linkvideo" /></td>
  </tr>
  <tr>
    <td colspan="2">
      <input type="submit" name="them" value="Thêm">    </td>
  </tr>
</table>
</form>



