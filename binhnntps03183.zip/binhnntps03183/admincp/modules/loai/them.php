<form action="modules/loai/xuly.php" method="post">
<table width="200" border="1">
  <tr>
    <td colspan="2">Thêm loại</td>
  </tr>
  <tr>
    <td>loại</td>
    <td>
    <input type="text" name="loai" id="loai"></td>
  </tr>
  <tr>
    <td colspan="2">
    <input type="submit" name="them" value="Thêm">    </td>
  </tr>
</table>
</form>



