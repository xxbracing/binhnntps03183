
<div class="menu">
    	<ul>
        	<li><a href="index.php?xem=trangchu">Trang chủ</a></li>
            <li><a href="index.php?xem=huongdan">Hướng dẫn mua hàng</a></li>
            <li><a href="index.php?xem=thanhtoan">Đăng nhập</a></li>
             <li><a href="index.php?xem=dangky">Đăng ký</a></li>
                <li><a href="index.php?xem=tintuc">Tin tức</a></li>
                <li><a href="index.php?xem=video">Video</a></li>
            <li><a href="index.php?xem=contact">Liên hệ</a></li>         
            <li><a href="index.php?xem=cart">Giỏ hàng <img src="image/14085970186309_icon-giao-hang.png" width="20" height="25" /></a></li>			<form action="index.php?xem=ketqua" method="post">
       		<p style="line-height:40px;padding-top:10px;">
            	<input type="text" name="search_query" size="15" style="float:left" /><input type="submit" name="search" value="Tìm kiếm" />
                 
            </p>
            </form>
        </ul>
    </div>