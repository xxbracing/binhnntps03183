<div class="header">
    	<img src="image/e-commerce-banner.jpg" width="1000px" height="150px" />
      
    </div>